import Rotas from './Rotas';
import './App.css';

function App() {
  return (
    <Rotas />
  );
}

export default App;
